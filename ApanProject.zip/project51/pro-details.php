<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link src="img/demo(1).png" type="image/x-icon" rel="incon">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <a href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></a>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body id="bd">
<?php
include "inc/header.php"
?>
<div class="container my-2 card">
    <div class="row">
        <div class="col-lg-1 my-2">
            <div class="card">
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                </div>
            
                
            
        </div>
        <div class="col-lg-4 card">
                <img src="img/s1.jpg" class="w-100 d-block">
            </div>
        <div class="col-lg-5 my-2">
            <div><h5>Portronics Toad 23 Wireless Optical Mouse with 2.4GHz, USB Nano Dongle, Optical Orientation, Click Wheel, Adjustable DPI(Black)
</h5>
<span class="rate"><a href="">Ratting</a>|</span>
<span class="rate"><a href="">Ratting</a>|</span>
<span class="rate"><a href="">Ratting</a></span>
</div>
<hr>
<div class="">
    <a href="#" class="btn btn-danger">Deal</a>
    <span class="d-flex"><h2 style="color:red">-50% off</h2>
    <h2 style="margin-left:15px;"><sup>₹</sup>149.00</h2></span>
    <span class="d-flex"><p>M.R.P.:</p><p><del>₹499</del></p></span>
    <span>Inclusive of all taxes
</span>
    

</div>
<hr>
<div class="div">
<h3>Abot Item</h3>
<ul>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
</ul>
</div>
        </div>
        <div class="col-lg-2 card">
            <div class="div">
                <h2><sup>₹</sup>299<sup>00</sup></h2>
                <span>
                    <a href="" id="link5">Free Delivery</a>
                    <strong>Friday 22,july 2023</strong>
                    on your first order
                </span>
            </div>
            <div class="div"><span>Quanlity</span>
            <select>
                <option>item</option>
                <option>1</option>
                <option>2</option>
                 <option>3</option>
                <option>4</option>
                <option>5</option>

            </select>
        </div>
        <div class="btn">
        <button class="btn btn-warning">Add to Cart</button>
            <button class="btn btn-danger">Buy Now</button>
        </div>
            

        </div>
    </div>
</div>
</body>
</html>