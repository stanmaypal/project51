<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="../tinymce/tinymce.min.js"></script>
    <script>
  tinymce.init({
    selector: 'textarea',
    plugins: 'advlist autolink lists link image charmap print preview',
    toolbar: 'undo redo | bold italic underline | bullist numlist | link image'
  });
</script>
</head>
<body>
    <textarea class="tinymce-editor"></textarea>
</body>
</html>