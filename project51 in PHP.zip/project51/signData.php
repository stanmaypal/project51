<?php
if(isset($_POST['submit']))
{
    include "database.php";// add  database
  
    $user=$_POST['user'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $pass=$_POST['pass'];
    $cpass=$_POST['cpass'];
    echo "pal";
    echo $cpass;
   

    if($pass==$cpass)
    {
 $sql = "INSERT into user (name,email,phone,passs) values('$user','$email','$phone','$pass')";
// echo $sql;
// die();
if(mysqli_query($conn,$sql))
{
    header('Location:index.php');
}
else
{
    echo "data not inserted";
}
    }
    else{
        echo "password not matched";
    }
   
die();
}
?>