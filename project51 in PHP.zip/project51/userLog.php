<?php
if(isset($_POST['user']) && isset($_POST['pass'])) {
    $username = $_POST['user'];
    $password = $_POST['pass'];

  include 'database.php';

    // Check if user exists
    $query = "SELECT * FROM user WHERE name = '$username' ";
//    echo $query;
// die();
    $result = mysqli_query($conn,$query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
            if ($password== $user['passs']) {
                session_start();
              $_SESSION['name']=$user['name'];
             
                 $_SESSION['passs']=$user['passs'];
                 $_SESSION['id']=$user['id'];
               
           header("Location:index.php");
           echo "<script>alert('Successfuly Log In'); window.location.href = 'index.php';</script>";

        } else {
            echo "<script>alert('Invalid Id and Password');";
        }
    } else {
        echo "<script>alert('Invalid Id and Password');";
    }

    
}
?>