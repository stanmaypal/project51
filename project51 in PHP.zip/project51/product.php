<!DOCTYPE html>
<html lang="en">
<head>
    <met a charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link src="img/demo(1).png" type="image/x-icon" rel="incon">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <a href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></a>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body id="bd">
<?php
include "inc/header.php"
?>


<div class="container my-2">
    <div class="row">
    <?php

include "database.php";

// Number of results per page
$resultsPerPage = 4;

// Get the current page number from the query parameter
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($current_page < 1) {
    $current_page = 1;
}

// Check if a search term is provided
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

// SQL query with search functionality and pagination
$sql = "SELECT COUNT(*) as total FROM product";
if (!empty($search)) {
    $sql .= " WHERE pro_name LIKE '%$search%'";
}
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$totalResults = $row['total'];

// Calculate the total number of pages
$totalPages = ceil($totalResults / $resultsPerPage);

// Ensure the current page is within bounds
if ($current_page > $totalPages) {
    $current_page = $totalPages;
}

$offset = ($current_page - 1) * $resultsPerPage;

$sql = "SELECT * FROM product";
if (!empty($search)) {
    $sql .= " WHERE pro_name LIKE '%$search%'";
}
$sql .= " LIMIT $offset, $resultsPerPage";
$result = mysqli_query($conn, $sql);

// Rest of your existing code..

    
    while($row = mysqli_fetch_assoc($result))
    {
      
?>
        <div class="col-lg-3 card">
       
        <div>
        <span style="margin-top:8px;color:red;"><b><?php echo $row['dis_per']; ?>% Off</b></span>

        <span style="float:right;margin-top:8px"><i class="fa fa-heart" style="font-size:25px;color:gray"></i>
</span>
           <center>
        
           <a href="pro-details.php?proId=<?php echo($row['id']);?>" >
                                  <img class="my-2 img1" height="280px" width="240px" src="admin/img/<?php echo $row['img1'];?> ">
    </a>
                                </center>
        </div>
        <div class="head2"> <h3><?php echo $row['pro_name']; ?></h3>
    <span>₹ <strike> <?php echo $row['price']; ?>.0</strike> ₹ <?php echo $row['dis_price']; ?></span> <br>
    <a href="pro-details.php?proId=<?php echo($row['id']);?>" class="btn btn-danger">Buy</a>
    <button class="btn btn-success">Add Cart</button>

    </div>
        </div>
        <?php
    }        
        ?>
       
<!-- Pagination buttons -->
<div class="container my-5">
    <div class="row">
        <div class="col-lg-12">
            <ul class="pagination justify-content-center">
                <?php if ($current_page > 1): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo ($current_page - 1); ?>">Previous</a></li>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo ($i === $current_page) ? 'active' : ''; ?>"><a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                <?php endfor; ?>
                <?php if ($current_page < $totalPages): ?>
                    <li class="page-item"><a class="page-link" href="?page=<?php echo ($current_page + 1); ?>">Next</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
    </div>
</div>
</body>
</html> 