<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link src="img/demo(1).png" type="image/x-icon" rel="incon">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <a href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></a>
</head>
<body id="bd">
  
  <?php 
  include "inc/header.php";
  ?>
  <div class="container my-5">
    <div class="row">
        <table class="table bg-info">
            <tr>
                <th>Sr</th>
                <th>Product Name</th>
                <th>Price</th>
            </tr>
            <?php
                  include "database.php";
                  $user=$_SESSION['id'];
                  $sql11="select * from cart Where userId='$user'";
                    $select=mysqli_query($conn,$sql11);
                    
                   // $row=mysqli_num_rows($select);
                    while($row=mysqli_fetch_assoc($select))
                    {
                        echo '<tr>';
                        echo '<td>'.$row['userId'].'</td>';
                        echo '<td>'.$row['name'].'</td>';
                        echo '<td>'.$row['price'].'</td>';
                        echo '</tr>';
                     
                       
                    }
           
                   ?>

        </table>
    </div>
  </div>
  </body>
  </html>