<?php
if(isset($_POST['btn']))
{
    include "../database.php";// add  database
    $ntc=$_POST['nav'];
    $nlink=$_POST['navLink'];
    $date= date("Y-m-d");

    $sql = "INSERT into nav (nav_name,link) values('$ntc','$nlink')";
// echo $sql;
// die();
if(mysqli_query($conn,$sql))
{
    header('Location:dash.php');
}
else
{
    echo "data not inserted";
}
die();
}
?>