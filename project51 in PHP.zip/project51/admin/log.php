<?php
if(isset($_POST['user']) && isset($_POST['pass'])) {
    $username = $_POST['user'];
    $password = $_POST['pass'];

  include '../database.php';

    // Check if user exists
    $query = "SELECT * FROM log WHERE user = '$username' ";
//    echo $query;
// die();
    $result = mysqli_query($conn,$query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
            if ($password== $user['password']) {
                session_start();
              $_SESSION['user']=$user['user'];
             
                 $_SESSION['password']=$user['password'];
               
           header("Location:dash.php");
        } else {
            echo "Invalid username or password";
        }
    } else {
        echo "Invalid username or password";
    }

    
}
?>