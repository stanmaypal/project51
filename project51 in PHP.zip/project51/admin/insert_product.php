<?php
if (isset($_POST['btn'])) {
    include "../database.php"; // Add database connection

    // Sanitize and validate user inputs
    $pname =$_POST['pname'];
    $pdetails =$_POST['pdetails'];
    $price = $_POST['price'];
    $disPer = $_POST['disper'];
    $about = $_POST['pabout'];


    $disPrice =$price-($price*$disPer/100);


    $folder = "./img/"; // Make sure 'img' directory exists

    // Check for file upload errors
      if ($_FILES["mimg1"]["error"] === 0 &&
        $_FILES["mimg2"]["error"] === 0 &&
        $_FILES["mimg3"]["error"] === 0 &&
        $_FILES["mimg4"]["error"] === 0 &&
        $_FILES["mimg5"]["error"] === 0 &&
        $_FILES["mimg6"]["error"] === 0) {

        // Move uploaded files to the folder
        $filename1 = $_FILES["mimg1"]["name"];
        $filename2 = $_FILES["mimg2"]["name"];
        $filename3 = $_FILES["mimg3"]["name"];
        $filename4 = $_FILES["mimg4"]["name"];
        $filename5 = $_FILES["mimg5"]["name"];
        $filename6 = $_FILES["mimg6"]["name"];

        move_uploaded_file($_FILES["mimg1"]["tmp_name"], $folder . $filename1);
        move_uploaded_file($_FILES["mimg2"]["tmp_name"], $folder . $filename2);
        move_uploaded_file($_FILES["mimg3"]["tmp_name"], $folder . $filename3);
        move_uploaded_file($_FILES["mimg4"]["tmp_name"], $folder . $filename4);
        move_uploaded_file($_FILES["mimg5"]["tmp_name"], $folder . $filename5);
        move_uploaded_file($_FILES["mimg6"]["tmp_name"], $folder . $filename6);

        $sql = "INSERT into product (pro_name, pro_datails, price, dis_price, dis_per, pro_about, img1, img2, img3, img4, img5, img6)
            VALUES ('$pname', '$pdetails', '$price', '$disPrice', '$disPer', '$about', '$filename1', '$filename2', '$filename3', '$filename4', '$filename5', '$filename6')";
// echo $sql;
// die();
        if (mysqli_query($conn, $sql)) {
            echo "Data inserted successfully";
            // header('Location:from.php');
            header('Location:index.html');
            exit();
        } else {
            echo "Data not inserted: " . mysqli_error($conn);
        }
    } 
    else {
        echo "File upload error occurred.";
    }
}
?>
