<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <a href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></a>
  <script src="../tinymce/tinymce.min.js"></script>
  <script>
  tinymce.init({
    selector: 'textarea',
    plugins: 'advlist autolink lists link image charmap print preview',
    toolbar: 'undo redo | bold italic underline | bullist numlist | link image'
  });
</script>

</head>
<body id="bd">
    <div class="container">
        <div class="row">
        <center><h1>Add Product Page</h1>
  <form class="border-2 card" style="width:50%" action="insert_product.php" method="post" enctype="multipart/form-data">
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Product name</label>
    <input type="text" class="form-control" placeholder="" name="pname" id="exampleInputPassword1">
  </div>
  
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Product Details</label>
    <textarea class="tinymce-editor" name="pdetails"></textarea>
  </div>
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Price</label>
    <input type="text" class="form-control" placeholder="" name="price" id="exampleInputPassword1">
  </div>
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Dis Percentage</label>
    <input type="text" class="form-control" placeholder="" name="disper" id="exampleInputPassword1">
  </div>
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Product About</label>
    <textarea class="tinymce-editor" name="pabout"></textarea>

  </div>
  <div class="mb-3" style="">
    <label for="exampleInputEmail1" class="form-label">Image 1</label>
    <input type="file" class="form-control" id="exampleInputEmail1" name="mimg1" aria-describedby="emailHelp">
      </div>

      <div class="mb-3" style="">
    <label for="exampleInputEmail1" class="form-label">Image 2</label>
    <input type="file" class="form-control" id="exampleInputEmail1" name="mimg2" aria-describedby="emailHelp">
      </div>

      <div class="mb-3" style="">
    <label for="exampleInputEmail1" class="form-label">Image 3</label>
    <input type="file" class="form-control" id="exampleInputEmail1" name="mimg3" aria-describedby="emailHelp">
      </div>

      <div class="mb-3" style="">
    <label for="exampleInputEmail1" class="form-label">Image 4</label>
    <input type="file" class="form-control" id="exampleInputEmail1" name="mimg4" aria-describedby="emailHelp">
      </div>

      <div class="mb-3" style="">
    <label for="exampleInputEmail1" class="form-label">Image 5</label>
    <input type="file" class="form-control" id="exampleInputEmail1" name="mimg5" aria-describedby="emailHelp">
      </div>

      <div class="mb-3" style="">
    <label for="exampleInputEmail1" class="form-label">Image 6</label>
    <input type="file" class="form-control" id="exampleInputEmail1" name="mimg6" aria-describedby="emailHelp">
      </div>

    
  
  <button type="submit" style="margin-bottom:10px;" name="btn" class="btn btn-primary">Submit</button>
</form>
</center>


        </div>
    </div>
  
</body>
</html>