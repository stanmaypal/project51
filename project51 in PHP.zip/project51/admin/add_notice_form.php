<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <a href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></a>
</head>
<body id="bd">
    <div class="container">
        <div class="row">
        <center><h1>Add Notice Page</h1>
  <form class="border-2 card" style="width:30%" action="add_notice.php" method="post" enctype="multipart/form-data">
  
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Write Notice</label>
    <input type="text" class="form-control" placeholder="Write Notice...." name="ntc" id="exampleInputPassword1">
  </div>
  
  
  <button type="submit" style="margin-bottom:10px;" name="btn" class="btn btn-primary">Submit</button>
</form>
</center>


        </div>
    </div>

    <div class="container">
      <div class="row">
    
      <?php
include "../database.php";

if (isset($_GET['page'])) {
    $page = $_GET['page'];
} else {
    $page = 1;
}
$limit = 2;
$offset = ($page - 1) * $limit;

$sql = "SELECT * FROM natice ORDER BY id DESC LIMIT {$offset}, {$limit}";
$result = mysqli_query($conn, $sql) or die("query failed");

?>
<!-- Rest of your HTML code -->

<div class="container">
    <div class="row">
        <table class="table">
            <tr>
                <th>Sr.</th>
                <th>Notice</th>
                <th>Date</th>
            </tr>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['ntc_name']; ?></td>
                        <td><?php echo $row['ntc_date']; ?></td>
                    </tr>
                    <?php
                }
            }
            ?>
        </table>

        <?php
        $sql1 = "SELECT * FROM natice";
        $result1 = mysqli_query($conn, $sql1) or die("query failed");
        $total_record = mysqli_num_rows($result1);
        $total_pages = ceil($total_record / $limit);

        echo '<ul class="pagination">';
        if($page>1)
        {
          echo '<li>      <a class="page-link" href="add_notice_form.php?page=' . ($page - 1) . '">Previous</a></li>';

        }
        for ($i = 1; $i <= $total_pages; $i++) {
          if($i==$page)
          {
              $active="active";
          }
          else{
              $active="";
          }
            echo '<li class="'.$active.'"><a class="page-link" href="add_notice_form.php?page=' . $i . '">' . $i . '</a></li>';
        }
        if($total_pages>$page)
        {
          echo '<li>      <a class="page-link" href="add_notice_form.php?page=' . ($page + 1) . '" >Next</a></li>';

        }

        echo '</ul>';
        ?>
    </div>
</div>

   <!-- <nav aria-label="...">
  
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1">Previous</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item active">
      <a class="page-link" href="#">2</a>
    </li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>-->
      </div>
    </div>
  
</body>
</html>