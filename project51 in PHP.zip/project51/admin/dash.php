<?php
include "session.php";
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <title>Dashboard</title>
  <style>
    /* Custom styles */
    body {
      padding: 0;
    }

    .dashboard-container {
      display: flex;
    }

    .sidebar {
      width: 250px;
      background-color: #f8f9fa;
      padding: 20px;
      border-right: 1px solid #dee2e6;
    }

    .sidebar ul.nav {
      list-style-type: none;
      padding-left: 0;
    }

    .sidebar .nav-link {
      color: #000;
    }

    .sidebar .nav-link:hover {
      text-decoration: none;
    }

    .content {
      flex-grow: 1;
      padding: 20px;
    }

    .dashboard-header {
      margin-bottom: 20px;
    }

    .dashboard-title {
      font-size: 24px;
      font-weight: bold;
    }

    .card {
      margin-bottom: 20px;
    }
    .dashboard-header
    {
        background-color: red;
    }
  </style>
</head>

<body>
<h1>Welcome to <?php echo $_SESSION['user'];?></h1>
  <div class="dashboard-container">
    
    <div class="sidebar">
      <ul class="nav flex-column">
        <li class="nav-item">
          <a class="nav-link active" href="#">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logOut.php">Log Out</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_slider_form.php">Add Slider</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_nav_form.php">Add Nav</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_notice_form.php">Add Notice</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_product.php">Add Product</a>
        </li>
      </ul>
    </div>

    <div class="content">
      <div class="dashboard-header">
        <h1 class="dashboard-title">Dashboard Welcome to <?php echo $_SESSION['user'] ?></h1>
      </div>

      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Card 1</h5>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Card 2</h5>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Card 3</h5>
                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- <script>
        // Prevent re-redirecting to dashboard after logout
        if (performance.navigation.type === 2) {
            // 2 is the value for TYPE_BACK_FORWARD navigation
            window.location.href = 'index.php';
        }
    </script> -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
