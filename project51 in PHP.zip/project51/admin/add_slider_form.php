<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../css/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <a href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></a>
</head>
<body id="bd">
    <div class="container">
        <div class="row">
        <center><h1>Add Slide Page</h1>
  <form class="border-2 card" style="width:30%" action="add_slier.php" method="post" enctype="multipart/form-data">
  <div class="mb-3" style="">
    <label for="exampleInputEmail1" class="form-label">Select Slider</label>
    <input type="file" class="form-control" id="exampleInputEmail1" name="mimg" aria-describedby="emailHelp">
      </div>
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Write Heading</label>
    <input type="text" class="form-control" placeholder="Write heading...." name="head" id="exampleInputPassword1">
  </div>
  <div class="mb-3" style="">
    <label for="exampleInputPassword1" class="form-label">Write Content</label>
    <input type="text" class="form-control" placeholder="Write Content...." name="cnt" id="exampleInputPassword1">
  </div>
  
  <button type="submit" style="margin-bottom:10px;" name="btn" class="btn btn-primary">Submit</button>
</form>
</center>


        </div>
    </div>

    <div class="container">
      <div class="row">
        <table class="table">
   <tr>
   <th>Sr..</th>
   <th>Content</th>
   <th>Discription</th>
  

</tr>
<?php
include"../database.php";
if(isset($_GET['pages']))
{
  $page=$_GET['pages'];
}
else{
  $page=1;
}

$limit=4;
$offset=($page - 1) * $limit;
$sql="select * from slider LIMIT {$offset},{$limit}";
// echo $sql;
// die();
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result))
{
  while($row=mysqli_fetch_assoc($result))
  {
   echo '<tr>'; 
   echo '<td>'.$row['id'].'</td>';
   echo '<td>'.$row['head'].'</td>';
   echo '<td>'.$row['content'].'</td>';

   echo '</tr>'; 
  }
}
{

}
?>
        </table>

        <?php
        $sql1="select * from slider";
        $result1=mysqli_query($conn,$sql1);

        $totalData=mysqli_num_rows($result1);
       
        $totalPages=ceil($totalData/$limit);
        echo '<ul class="pagination">';
        if($page>1){
          echo '    <li class="page-item"><a class="page-link" href="add_slider_form.php?pages='.($page - 1).'">Previous</a></li>';

        }
        for($i=1;$i<=$totalPages;$i++)
        {
          if($page==$i)
          {
            $active="active";
          }
          else{
            $active="";
          }
          echo '<li class="page-item"><a class="page-link '.$active.'" href="add_slider_form.php?pages='.$i.'">'.$i.'</a></li>';
        }
        if($totalPages>$page)
        {
          echo ' <li class="page-item"><a class="page-link" href="add_slider_form.php?pages='.($page + 1).'">Next</a></li>';

        }

        echo '</ul>'
        ?>

        <!--<nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item"><a class="page-link" href="#">Next</a></li>
  </ul>
</nav>-->
      </div>
    </div>
  
</body>
</html>