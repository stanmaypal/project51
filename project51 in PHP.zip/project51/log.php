<?php
if(isset($_POST['user']) && isset($_POST['pass'])) {
    $username = $_POST['user'];
    $password = $_POST['pass'];
// echo $username;
// echo $password;

    // TODO: Validate username and password

    // Connect to database
  include 'database.php';

    // Check if user exists
    $query = "SELECT * FROM log WHERE user = '$username' ";
//    echo $query;
// die();
    $result = mysqli_query($conn,$query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
            if ($password== $user['password']) {
                session_start();
                $_SESSION['user']=$user['user'];
                $_SESSION['password']=$user['password'];
                setcookie('user', $user['user'], time() + 60 * 60 * 24 * 30, '/');
            setcookie('id', $user['id'], time() + 60 * 60 * 24 * 30, '/');

            header("Location: admin/index.php");
        } else {
            echo "Invalid username or password";
        }
    } else {
        echo "Invalid username or password";
    }

   
}
?>