<?php
include "database.php";

session_start();
session_unset();
session_destroy();
unset($_SESSION['user']);
setcookie('user',$_SESSION['user'],time()+60);


// if(session_destroy()&& session_unset())
// {
//     $_SESSION['user']="User";
// }
echo "<script>alert('Successfuly Log Out'); window.location.href = 'index.php';</script>";

?>