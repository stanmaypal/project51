
<?php
include "database.php";
session_start();
if (isset($_COOKIE['user'])) {
    header('Location: index.php');
     // Make sure to exit after redirection.
    
}
else if(isset($_SESSION['user']))
{
  header('Location: index.php');
}
// echo $_SESSION['user'];
// die();
?>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="">New message</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action ="userLog.php" method="post">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="text" name="user" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" name="pass" class="form-control" id="exampleInputPassword1">
  </div>
  <a href="userSign.php"class="btn btn-primary"> SignUp </a>
  
  <button type="submit" name="submit" class="btn btn-primary">Log In</button>
</form>
      </div>
      
    </div>
  </div>
</div>
<div class="container-fluid head1">
    <span><strong>Phone</strong>9876543210</span>  
    <span style="float: right;"><strong>Email</strong>project51@gmail.com</span>    

    </div>
    <div class="container">
    <div class="row">
        <div class="col-sm-3 col-lg-3"><center><img src="img/logo.png" class="logo"></center></div>
        <div class="col-sm-9 col-lg-9"><h1 id="topic" class="text-center">Project_51</h1></div>

    </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                <?php

                if(isset($_SESSION['id']))
                {
                  $sql9 = "SELECT name FROM user WHERE id='$_SESSION[id]'";
                  $query = mysqli_query($conn,$sql9);
                  $row=mysqli_fetch_array($query);
                  echo '<h4 class="text-danger"> Hi,'.$row["name"].'</h4>';
                }
                // else if(isset($_COOKIE['id']))
                // {
                //   $sql = "SELECT name FROM user WHERE id='$_COOKIE[id]'";
                //   $query = mysqli_query($conn,$sql9);
                //   $row=mysqli_fetch_array($query);
                //   echo '<h4 class="text-danger">'.$row["name"].'</h4>';
                // }
                else{
                  echo '<h4 class="text-danger">Hi,User</h4>';

                }
                ?>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
      <a class="nav-link active" aria-current="page" href="index.php">Home</a>
    </li>
                        
<?php
include "database.php";
$sql="SELECT * FROM nav "; // Fix: Added * to select all columns
    $result = mysqli_query($conn, $sql);
    
    while($row = mysqli_fetch_assoc($result))
    {
      
?>
      <li class="nav-item">
      <a class="nav-link active" aria-current="page" href="<?php echo($row['link']);?>.php"><?php echo $row['nav_name']; ?></a>
    </li>
    <?php
    }
    ?>
    <li class="nav-item">
      <a class="btn btn-primary pa" href="./admin/">Admin</a></li>
      <?php
      if(isset($_SESSION['id']))
      {
        echo ' <li><a class="btn btn-danger pa"  href="out.php">Log Out</a></li>';
      }
      else{
        echo '    <li><a class="btn btn-danger pa"  data-bs-toggle="modal" data-bs-target="#exampleModal">Log In</a></li>
        ';
      }
      ?>
  
    
      
      
    </ul>

                            <form class="d-flex" action="" method="GET" >
                    <input type="search" name="search" class="form-control" placeholder="Search products" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button type="submit" class="btn btn-primary">Search</button>

               <ul>
                  <?php
                  
                  if(isset($_SESSION['id']))
                  {
                    $user=$_SESSION['id'];
                    $sql11="select * from cart Where userId='$user'";
                      $select=mysqli_query($conn,$sql11);
                      $row=mysqli_num_rows($select);
                      echo '<li class="nav-link"><a class="text-danger" style="text-decoration:none;"  href="cart.php">Cart<sup>' . $row . '</sup></a></li>';
                     

                  }
                  else{
                     // echo'<li class="nav-link"><a class="text-danger" style="text-decoration:none;"  href="cart.php">Cart<sup>0</sup></a></li>';
                  }
                  ?>
              
                
                   
              </ul>
                    </form>
                  </div>
                </div>
              </nav>
        </div>
    </div>

    <script>
     // event.preventDefault();
     var exampleModal = document.getElementById('exampleModal')
exampleModal.addEventListener('show.bs.modal', function (event) {
  // Button that triggered the modal
  var button = event.relatedTarget
  // Extract info from data-bs-* attributes
  var recipient = button.getAttribute('data-bs-whatever')
  // If necessary, you could initiate an AJAX request here
  // and then do the updating in a callback.
  //
  // Update the modal's content.
  var modalTitle = exampleModal.querySelector('.modal-title')
  var modalBodyInput = exampleModal.querySelector('.modal-body input')

  modalTitle.textContent = 'New message to ' + recipient
  modalBodyInput.value = recipient
})
  </script>