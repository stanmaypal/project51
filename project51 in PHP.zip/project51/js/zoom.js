<script>
  function zoom(event) {
    const image = event.currentTarget.querySelector('img');
    const containerWidth = event.currentTarget.clientWidth;
    const containerHeight = event.currentTarget.clientHeight;
    const imageWidth = image.width;
    const imageHeight = image.height;

    // Calculate the zoom factor based on container and image sizes
    const scaleX = containerWidth / imageWidth;
    const scaleY = containerHeight / imageHeight;

    // Adjust the zoom level (you can tweak the factor for your desired zoom level)
    const zoomLevel = 1.5;

    // Calculate the position within the image to focus on
    const offsetX = (event.offsetX / containerWidth) * imageWidth;
    const offsetY = (event.offsetY / containerHeight) * imageHeight;

    // Apply the zoom effect using the transform property
    image.style.transform = `scale(${zoomLevel})`;
    image.style.transformOrigin = `${offsetX}px ${offsetY}px`;
  }

  function resetZoom(event) {
    const image = event.currentTarget.querySelector('img');
    image.style.transform = 'scale(1)';
    image.style.transformOrigin = '50% 50%';
  }

  const productImage = document.querySelector('.product-image');
  productImage.addEventListener('mouseout', resetZoom);
</script>
