-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2023 at 09:20 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project51`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` bigint(20) NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `userId`) VALUES
(15, 'Camera', 7109, 3),
(16, 'Lava T1820', 1068, 1),
(17, 'Laptop', 14250, 1),
(18, 'Realme 11', 26970, 1),
(19, 'Lava T1820', 1068, 5),
(20, 'Realme 11', 26970, 5),
(21, 'Camera', 7109, 5),
(22, 'Camera', 7109, 1),
(23, 'KeyBord', 960, 1),
(24, 'KeyBord', 960, 5),
(25, 'Laptop', 14250, 6),
(26, 'Camera', 7109, 7),
(27, 'Laptop', 14250, 7);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `dob` date DEFAULT NULL,
  `phone` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `user`, `password`, `dob`, `phone`) VALUES
(1, 'sarvesh@123', '123', '0000-00-00', 123456789),
(2, 'Tanmay', '12345', '0000-00-00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `natice`
--

CREATE TABLE `natice` (
  `id` int(11) NOT NULL,
  `ntc_name` varchar(100) NOT NULL,
  `ntc_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `natice`
--

INSERT INTO `natice` (`id`, `ntc_name`, `ntc_date`) VALUES
(1, 'Holiday', '2023-07-13'),
(2, 'Tanmay', '2023-07-13'),
(3, '', '2023-07-13'),
(4, 'Demo notice', '2023-07-14'),
(5, 'Demo notice', '2023-07-25'),
(6, 'Hello Dev', '2023-07-27');

-- --------------------------------------------------------

--
-- Table structure for table `nav`
--

CREATE TABLE `nav` (
  `id` int(11) NOT NULL,
  `nav_name` varchar(50) DEFAULT NULL,
  `link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nav`
--

INSERT INTO `nav` (`id`, `nav_name`, `link`) VALUES
(7, 'Product', 'product'),
(8, 'Balaji', 'balaji'),
(9, 'Product', 'product');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `pro_name` varchar(50) NOT NULL,
  `pro_datails` text NOT NULL,
  `price` int(11) NOT NULL,
  `dis_price` int(11) NOT NULL,
  `dis_per` int(11) NOT NULL,
  `pro_about` text NOT NULL,
  `img1` varchar(150) NOT NULL,
  `img2` varchar(150) NOT NULL,
  `img3` varchar(150) NOT NULL,
  `img4` varchar(150) NOT NULL,
  `img5` varchar(150) NOT NULL,
  `img6` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `pro_name`, `pro_datails`, `price`, `dis_price`, `dis_per`, `pro_about`, `img1`, `img2`, `img3`, `img4`, `img5`, `img6`) VALUES
(3, 'Camera', '<p>Good</p>', 8999, 7109, 21, '<p>Good</p>', 'cmr.jpg', 'cmr.jpg', 'cmr.jpg', 'cmr.jpg', 'cmr.jpg', 'cmr.jpg'),
(4, 'Realme 11', '<p>Best</p>', 29000, 26970, 7, '<p>Best</p>', 'real.jpg', 'real.jpg', 'real.jpg', 'real.jpg', 'real.jpg', 'real.jpg'),
(5, 'Laptop', '<p>GOOD</p>', 15000, 14250, 5, '<p>cdcndn</p>', 'lp.jpg', 'lp.jpg', 'lp.jpg', 'lp.jpg', 'lp.jpg', 'lp.jpg'),
(6, 'Lava T1820', '<p>Lava BLAZE NXT comes with a Premium Glass Back Design with Large 64GB ROM and 4GB+3GB* RAM (*Virtual RAM) &amp; 13MP Triple AI Rear Camera. First Smartphone in the segment to be Powered by a Clean Android 12 OS. Offers 6.5 inch HD+ IPS display, powerful 5000 mAh battery, Type C charging &amp; Bottom Firing Speakers. First in the industry to offer Free Service at Home.</p>', 1200, 1068, 11, '<ul>\r\n<li class=\"_21Ahn-\">4 GB RAM | 64 GB ROM | Expandable Upto 256 GB</li>\r\n<li class=\"_21Ahn-\">16.51 cm (6.5 inch) HD+ Display</li>\r\n<li class=\"_21Ahn-\">13MP Rear Camera | 8MP Front Camera</li>\r\n<li class=\"_21Ahn-\">5000 mAh Battery</li>\r\n<li class=\"_21Ahn-\">MediaTek G37 Processor</li>\r\n</ul>', 'l1.jpg', 'l1.jpg', 'lp.jpg', 'real.jpg', 'l1.jpg', 'lp.jpg'),
(7, 'KeyBord', '<h1 class=\"a-size-large a-spacing-none\"><span id=\"productTitle\" class=\"a-size-large product-title-word-break\">Portronics Bubble Multimedia Wireless Keyboard 2.4 GHz &amp; Bluetooth 5.0 Connectivity, Noiseless Experience, Compact Size, Shortcut Keys Function for iOS iPad Air, Pro, Mini, Android, Windows Tablets PC Smartphone(Black)</span></h1>', 1999, 960, 52, '<table class=\"a-normal a-spacing-micro\">\r\n<tbody>\r\n<tr class=\"a-spacing-small po-brand\">\r\n<td class=\"a-span3\"><span class=\"a-size-base a-text-bold\">Brand</span></td>\r\n<td class=\"a-span9\"><span class=\"a-size-base po-break-word\">Portronics</span></td>\r\n</tr>\r\n<tr class=\"a-spacing-small po-compatible_devices\">\r\n<td class=\"a-span3\"><span class=\"a-size-base a-text-bold\">Compatible Devices</span></td>\r\n<td class=\"a-span9\"><span class=\"a-size-base po-break-word\">PC, Tablet</span></td>\r\n</tr>\r\n<tr class=\"a-spacing-small po-connectivity_technology\">\r\n<td class=\"a-span3\"><span class=\"a-size-base a-text-bold\">Connectivity Technology</span></td>\r\n<td class=\"a-span9\"><span class=\"a-size-base po-break-word\">Bluetooth</span></td>\r\n</tr>\r\n<tr class=\"a-spacing-small po-keyboard_description\">\r\n<td class=\"a-span3\"><span class=\"a-size-base a-text-bold\">Keyboard Description</span></td>\r\n<td class=\"a-span9\"><span class=\"a-size-base po-break-word\">Wireless</span></td>\r\n</tr>\r\n<tr class=\"a-spacing-small po-recommended_uses_for_product\">\r\n<td class=\"a-span3\"><span class=\"a-size-base a-text-bold\">Recommended Uses For Product</span></td>\r\n</tr>\r\n</tbody>\r\n</table>', 'kbd.jpg', 'kbd.jpg', 'kbd.jpg', 'kbd.jpg', 'kbd.jpg', 'kbd.jpg'),
(8, 'Mouse', '<p>Good</p>', 150, 143, 5, '<p>OPtical&nbsp;</p>', 'ms.jpg', 'ms.jpg', 'ms.jpg', 'ms.jpg', 'ms.jpg', 'ms.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `head` varchar(50) NOT NULL,
  `content` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `image`, `head`, `content`) VALUES
(2, 'Screenshot 2023-07-11 121547.png', 'Hello ', 'How are you'),
(3, 'Screenshot (46).png', 'ppp', 'sss'),
(4, '2021-07-07 (2).png', 'Demo data ', 'this is a demo page ');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `passs` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `phone`, `passs`) VALUES
(1, 'sarvesh@123', 'tanmay0pal@gmail.com', 98765432, '123'),
(2, 'sarvesh@123', 'tanmay0pal@gmail.com', 98765432, '123'),
(3, 'suraj', 'su@gmail.com', 123456789, '12345'),
(5, 'Tanmay', 'tp@gmail.com', 1234567890, 'pal'),
(7, 'NIIT', 'nii@gmail.com', 9876543210, '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `natice`
--
ALTER TABLE `natice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nav`
--
ALTER TABLE `nav`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `natice`
--
ALTER TABLE `natice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `nav`
--
ALTER TABLE `nav`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
