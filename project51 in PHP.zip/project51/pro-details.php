<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link src="img/demo(1).png" type="image/x-icon" rel="incon">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <a href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"></a>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body id="bd">
<?php
include "inc/header.php"
?>
<div class="container-fluid my-2 card">
    <div class="row">
<?php 
include "database.php";
if(isset($_GET['proId']))
{
    $pId=$_GET['proId'];
    
   $sql5="select * from product where id={$pId}";
   $result5=mysqli_query($conn,$sql5);
   if(mysqli_num_rows($result5))
   {
    while($row=mysqli_fetch_assoc($result5))
    {
        echo' <div class="col-lg-1 my-2">';
        echo '  <div class="card">';
        echo '<span><img src="admin/img/'.$row['img2'].'" class="d-block s1" height="100px" width="100px"><span>';
        echo '<span><img src="admin/img/'.$row['img3'].'" class="d-block s1" height="100px" width="100px"><span>';
        echo '<span><img src="admin/img/'.$row['img4'].'" class="d-block s1" height="100px" width="100px"><span>';
        echo '<span><img src="admin/img/'.$row['img5'].'" class="d-block s1" height="100px" width="100px"><span>';
        echo '<span><img src="admin/img/'.$row['img6'].'" class="d-block s1" height="100px" width="100px"><span>';
        echo '</div>';
        echo '</div>';

        echo '<div class="col-lg-4 card">';
        echo '<body>
        <div class="product-image" onmousemove="zoom(event)">
        <img src="admin/img/'.$row['img1'].'" class=w-100 d-block">
    </div>';
        //echo ' <img src="admin/img/'.$row['img1'].'" class="w-100 d-block">';
        echo '</div>';
        echo '<div class="col-lg-5 my-2">';
            echo '<div>';
                echo '<h5>'.$row['pro_name'].'</h5>';
                echo '<h5>'.$row['pro_datails'].'</h5>';
                echo '<span class="rate"><a href="">Ratting</a>|</span>
                <span class="rate"><a href="">Ratting</a>|</span>
                <span class="rate"><a href="">Ratting</a></span>';

            echo '</div>';
            echo '<hr>';
            echo '<div>';
           echo' <a href="#" class="btn btn-danger">Deal</a>
            <span class="d-flex"><h2 style="color:red">-'.$row['dis_per'].'% off</h2>
            <h2 style="margin-left:15px;"><sup>₹</sup>'.$row['dis_price'].'.00</h2></span>
            <span class="d-flex"><p>M.R.P.:</p><p><del>₹'.$row['price'].'</del></p></span>
            <span>Inclusive of all taxes</span>';
            echo '</div>';

            echo'<hr>';

echo '<div class="div">
<h3>About Item</h3>
'.$row['pro_about'].'
</div>';


        
        echo'</div>';

        echo ' <div class="col-lg-2 card">';
            echo ' <div class="div">
            <h2><sup>₹</sup>'.$row['dis_price'].'<sup></sup></h2>
            <span>
                <a href="" id="link5">Free Delivery</a>
                <strong>'.date("Y-m-d", strtotime("+5 days")).'</strong>
                on your first order
            </span>
        </div>
        <div class="div"><span>Quanlity</span>
        <select>
            <option>item</option>
            <option>1</option>
            <option>2</option>
             <option>3</option>
            <option>4</option>
            <option>5</option>

        </select>
    </div>
    <div class="btn">
    <form action="addCart.php" method="post">
    <input type="text" value="'.$row['pro_name'].'" name="pname" hidden/>
    <input type="text" value="'.$row['dis_price'].'" name="price"hidden/>
    <button class="btn btn-warning" type="submit" name="pcart">Add to Cart</button>
        <button class="btn btn-danger">Buy Now</button>
        </form>';
        echo'</div>';
    }
   }


}
?>

<!--<div class="container my-2 card">
    <div class="row">
        <div class="col-lg-1 my-2">
            <div class="card">
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                <span><img src="img/s1.jpg" class="d-block s1" height="100px" width="100px"><span>
                </div>
            
                
            
        </div>
        <div class="col-lg-4 card">
                <img src="img/s1.jpg" class="w-100 d-block">
            </div>
        <div class="col-lg-5 my-2">
            <div><h5>Portronics Toad 23 Wireless Optical Mouse with 2.4GHz, USB Nano Dongle, Optical Orientation, Click Wheel, Adjustable DPI(Black)
</h5>
<span class="rate"><a href="">Ratting</a>|</span>
<span class="rate"><a href="">Ratting</a>|</span>
<span class="rate"><a href="">Ratting</a></span>
</div>
<hr>
<div class="">
    <a href="#" class="btn btn-danger">Deal</a>
    <span class="d-flex"><h2 style="color:red">-50% off</h2>
    <h2 style="margin-left:15px;"><sup>₹</sup>149.00</h2></span>
    <span class="d-flex"><p>M.R.P.:</p><p><del>₹499</del></p></span>
    <span>Inclusive of all taxes</span>
    

</div>
<hr>
<div class="div">
<h3>Abot Item</h3>
<ul>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
    <li>[WIRELESS FREEDOM] - Enjoy up to a 10-meter wireless connection with the Toad 23 wireless mouse’s tiny plug-and-forget wireless receiver. No software or driver installation needed. The mouse automatically connects to your computer system. It is ready to go when you are.</li>
</ul>
</div>
        </div>
        <div class="col-lg-2 card">
            <div class="div">
                <h2><sup>₹</sup>299<sup>00</sup></h2>
                <span>
                    <a href="" id="link5">Free Delivery</a>
                    <strong>Friday 22,july 2023</strong>
                    on your first order
                </span>
            </div>
            <div class="div"><span>Quanlity</span>
            <select>
                <option>item</option>
                <option>1</option>
                <option>2</option>
                 <option>3</option>
                <option>4</option>
                <option>5</option>

            </select>
        </div>
        <div class="btn">
        <button class="btn btn-warning">Add to Cart</button>
            <button class="btn btn-danger">Buy Now</button>
        </div>-->
            
<script>
  function zoom(event) {
    const image = event.currentTarget.querySelector('img');
    const containerWidth = event.currentTarget.clientWidth;
    const containerHeight = event.currentTarget.clientHeight;
    const imageWidth = image.width;
    const imageHeight = image.height;

    // Calculate the zoom factor based on container and image sizes
    const scaleX = containerWidth / imageWidth;
    const scaleY = containerHeight / imageHeight;

    // Adjust the zoom level (you can tweak the factor for your desired zoom level)
    const zoomLevel = 1.5;

    // Calculate the position within the image to focus on
    const offsetX = (event.offsetX / containerWidth) * imageWidth;
    const offsetY = (event.offsetY / containerHeight) * imageHeight;

    // Apply the zoom effect using the transform property
    image.style.transform = `scale(${zoomLevel})`;
    image.style.transformOrigin = `${offsetX}px ${offsetY}px`;
  }

  function resetZoom(event) {
    const image = event.currentTarget.querySelector('img');
    image.style.transform = 'scale(1)';
    image.style.transformOrigin = '50% 50%';
  }

  const productImage = document.querySelector('.product-image');
  productImage.addEventListener('mouseout', resetZoom);
</script>



        </div>
    </div>
</div>
</body>
</html>