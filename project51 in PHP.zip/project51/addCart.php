<?php
include "database.php";
session_start();
if (isset($_SESSION['user'])||isset($_COOKIE['user'])) {
    header('Location: index.php');
    exit(); // Make sure to exit after redirection.
    
}?>
<?php
if(isset($_POST['pcart']))
{
    include "database.php";// add  database
   $name=$_POST['pname'];
   $price=$_POST['price'];
   $user=$_SESSION['id'];

   $sql1="select * from cart where userId='$user' and name='$name'";
   $result=mysqli_query($conn,$sql1);
   if(mysqli_num_rows($result)>0)
   {
    $msg="Already exits";
        
        echo "<script>alert('$msg'); window.location.href = 'product.php';</script>";


   }
   else{
    if($user!=0)
{
    $sql = "INSERT into cart (name,price,userId) values('$name','$price','$user')";
    // echo $sql;
    // die();
    if(mysqli_query($conn,$sql))
    {
        
        echo "<script>alert('Successfuly Add to Cart'); window.location.href = 'product.php';</script>";

    }
    else
    {
        echo "data not inserted";
    }
}


   

//    echo $user;
//    echo $name;
//    echo $price;
//    die();

else{
    header("Location:index.php");
}

die();
}
}
?>